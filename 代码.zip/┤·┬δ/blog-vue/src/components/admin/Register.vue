<template>
    <el-form :model="loginForm" status-icon :rules="rules" ref="ruleForm" label-width="100px" class="loginForm"
        v-loading="loading">
        <el-form-item label="用户名" prop="username">
            <el-input v-model="loginForm.username" autocomplete="off"></el-input>
        </el-form-item>

        <el-form-item label="输入昵称" prop="nickname">
            <el-input v-model="loginForm.nickname" autocomplete="off"></el-input>
        </el-form-item>

        <el-form-item label="输入密码" prop="password">
            <el-input type="password" v-model="loginForm.password" autocomplete="off"></el-input>
        </el-form-item>

        <el-form-item label="确认密码" prop="repassword">
            <el-input type="password" v-model="loginForm.repassword" autocomplete="off"></el-input>
        </el-form-item>
        <!-- 添加验证码 -->
        <!-- <div> -->
        <!-- <ValidCode @update:value="getCode"/> -->
        <!-- <ValidCode
                style="border: 1px solid #ccc;margin-left: 100px; margin-bottom: 20px;width: auto; border-radius: 6px;">
            </ValidCode> -->
        <!-- </div> -->
        <!-- 输入验证码 -->
        <!-- <el-form-item label="输入验证码" prop="userCode">
            <el-input v-model="loginForm.userCode" autocomplete="off"></el-input>
        </el-form-item> -->

        <el-form-item>
            <!-- <el-button type="primary" @click="verifyCode">验证</el-button> -->
            <el-button type="primary" @click="submitForm">确认注册</el-button>
        </el-form-item>
    </el-form>
</template>

<script>
import axios from "axios";
// import ValidCode from "../ValidCode.vue";
export default {

    name: "Login",
    data() {
        return {
            code: '', // 生成的验证码
            userCode: '', // 用户输入的验证码

            loginForm: {
                username: '',
                nickname: '',
                password: '',
                repassword: '',
            },
            loading: false,
            rules: {
                username: [
                    { required: true, message: '请输入用户名', trigger: 'blur', len: 8 },
                ],
                nickname: [
                    { required: true, message: '请输入昵称', trigger: 'blur' }
                ],
                password: [
                    { required: true, message: '请输入密码', trigger: 'blur' },
                    { validator: this.validatePassword, trigger: 'blur' }
                ],
                repassword: [
                    { required: true, message: '请确认密码', trigger: 'blur', },
                    { validator: this.validateConfirmPassword, trigger: 'blur', }
                ],
            },

        };
    },





    methods: {

        getCode(code) {
            this.code = code;
        },

        verifyCode() {
            if (this.userCode === this.code) {
                this.$message({
                    message: '验证成功',
                    type: 'success'
                });
            } else {
                this.$message({
                    message: '验证码错误',
                    type: 'error'
                });
            }
        },

        submitForm() {
            this.loading = true;
            axios.post('/user/reg', {
                username: this.loginForm.username,
                password: this.loginForm.password,
                nickname: this.loginForm.nickname,
            }).then(value => {
                this.loading = false;
                const data = value.data

                // 密码校验
                if (this.loginForm.password !== this.loginForm.repassword) {
                    this.$message({
                        message: '两次输入的密码不一致',
                        type: 'error'
                    });
                    return;
                }



                if (data.success) {
                    this.$message({
                        message: '注册成功',
                        type: 'success'
                    });
                    this.$router.push({ path: '/login' });
                } else {
                    this.$message({
                        message: data.message,
                        type: 'error'
                    });
                }

            })
        },
    },
    // components: {
    //     ValidCode
    // }


}
</script>

<style scoped>
.loginForm {
    margin: 200px auto 100px;
    width: 400px;
    padding: 80px 100px 30px 0px;
    border-radius: 10px;
    box-shadow: 0px 0px 10px #dedede;
}
</style>
