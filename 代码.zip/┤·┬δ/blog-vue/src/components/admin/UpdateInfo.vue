<template>
  <div>更新信息页</div>
</template>

<script>
  export default {
    name: "UpdateInfo"
  }
</script>

<style scoped>

</style>
