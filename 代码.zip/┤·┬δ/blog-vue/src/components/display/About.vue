<template>
  <div class="about">一个学生而已，没什么好说的</div>
</template>

<script>
  export default {
    name: "About"
  }
</script>

<style scoped>
  .about {
    text-align: center;
  }
</style>
