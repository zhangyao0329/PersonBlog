package com.dkt.blogboot.req;

public class ArticleQueryReq extends PageReq {
    private String title;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
