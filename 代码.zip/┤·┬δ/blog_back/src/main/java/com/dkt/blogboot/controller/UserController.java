package com.dkt.blogboot.controller;

import com.dkt.blogboot.entity.Result;
import com.dkt.blogboot.entity.User;
import com.dkt.blogboot.req.UserInsertReq;
import com.dkt.blogboot.req.UserLoginReq;
import com.dkt.blogboot.resp.CommonResp;
import com.dkt.blogboot.resp.UserLoginResp;
import com.dkt.blogboot.service.MailService;
import com.dkt.blogboot.service.UserService;
import com.dkt.blogboot.util.JwtUtil;
import com.dkt.blogboot.util.Md5Util;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.util.DigestUtils;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.mail.MessagingException;
import javax.validation.Valid;
import javax.validation.constraints.Pattern;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

@Api(tags = "系统用户操作接口")
@Validated
@RestController
@RequestMapping("/user")
public class UserController {

    @Autowired
    UserService userService;
    @Autowired
    RedisTemplate redisTemplate;
    @Autowired
    private MailService mailService;

    @ApiOperation(value = "用户注册")
    @PostMapping("/reg")
    public CommonResp reg(@Valid @RequestBody UserInsertReq req) {
        req.setPassword(DigestUtils.md5DigestAsHex(req.getPassword().getBytes(StandardCharsets.UTF_8)));
        CommonResp<Object> resp = new CommonResp<>();
        userService.reg(req);
        return resp;
    }

    @ApiOperation(value = "用户登录")
    @PostMapping("/login")
    public CommonResp login(@Valid @RequestBody UserLoginReq req) throws Exception{
        req.setPassword(DigestUtils.md5DigestAsHex(req.getPassword().getBytes(StandardCharsets.UTF_8)));
        CommonResp resp = userService.login(req);
        UserLoginResp userLoginResp = (UserLoginResp) resp.getContent();
        redisTemplate.opsForValue().set(userLoginResp.getToken(), userLoginResp, 3600 * 24, TimeUnit.SECONDS);
        mailService.sendSimpleMessage("1870476411@qq.com", "登录提醒", "用户" + userLoginResp.getUsername() + "登录了系统");
        return resp;
    }

    @ApiOperation(value = "注销登录")
    @GetMapping("/logout/{token}")
    public CommonResp logout(@PathVariable("token") String token) {
        CommonResp resp = new CommonResp<>();
        redisTemplate.delete(token);
        return resp;
    }
}
