package com.dkt.blogboot.controller;

import com.dkt.blogboot.service.MailService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.mail.MessagingException;

@Api(tags = "发送邮件接口")
@RestController
public class MailController {

    @Autowired
    private MailService mailService;

    @ApiOperation(value = "给登录者发送邮件")
    @GetMapping("/sendEmail")
    public String sendEmail(
            @RequestParam(defaultValue = "1870476411@qq.com") String to,
            @RequestParam(defaultValue = "有人登录系统，请检查") String subject,
            @RequestParam(defaultValue = "This is a default message.") String text) {
        try {
            mailService.sendSimpleMessage(to, subject, text);
            return "有用户已登录，请检查邮箱。 Email sent successfully";
        } catch (MessagingException e) {
            e.printStackTrace();
            return "Error while sending email: " + e.getMessage();
        }
    }
}





