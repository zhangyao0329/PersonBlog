package com.dkt.blogboot.controller;

import com.dkt.blogboot.req.TagInsertReq;
import com.dkt.blogboot.resp.CommonResp;
import com.dkt.blogboot.resp.TagQueryResp;
import com.dkt.blogboot.service.ArticleService;
import com.dkt.blogboot.service.CategoryService;
import com.dkt.blogboot.service.TagService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@Api(tags = "文章标签接口")
@RestController
@RequestMapping("/tag")
public class TagController {

    @Autowired
    CategoryService categoryService;
    @Autowired
    TagService tagService;
    @Autowired
    ArticleService articleService;

    @ApiOperation(value = "获取所有标签")
    @GetMapping("/list")
    public CommonResp selectAllTag() {
        List<TagQueryResp> tagQueryResps = tagService.selectAll();
        CommonResp<List<TagQueryResp>> resp = new CommonResp<>();
        resp.setContent(tagQueryResps);
        return resp;
    }

    @ApiOperation(value = "添加文章标签")
    @PostMapping("/add")
    public CommonResp addTag(@Valid @RequestBody TagInsertReq req) {
        CommonResp<Object> resp = new CommonResp<>();
        tagService.insert(req);
        return resp;
    }

    @ApiOperation(value = "删除文章标签")
    @DeleteMapping("/delete/{id}")
    public CommonResp deleteTag(@PathVariable("id") Integer id) {
        return tagService.delete(id);
    }
}
