package com.dkt.blogboot.controller;

import com.dkt.blogboot.req.CategoryInsertReq;
import com.dkt.blogboot.resp.CategoryQueryResp;
import com.dkt.blogboot.resp.CommonResp;
import com.dkt.blogboot.service.ArticleService;
import com.dkt.blogboot.service.CategoryService;
import com.dkt.blogboot.service.TagService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@Api(tags = "文章分类接口")
@RestController
@RequestMapping("/category")
public class CategoryController {

    @Autowired
    CategoryService categoryService;
    @Autowired
    TagService tagService;
    @Autowired
    ArticleService articleService;

    @ApiOperation(value = "获取所有分类")
    @GetMapping("/list")
    public CommonResp selectAllCategory() {
        List<CategoryQueryResp> categoryQueryResps = categoryService.selectAll();
        CommonResp<List<CategoryQueryResp>> resp = new CommonResp<>();
        resp.setContent(categoryQueryResps);
        return resp;
    }

    @ApiOperation(value = "添加文章分类")
    @PostMapping("/add")
    public CommonResp addTag(@Valid @RequestBody CategoryInsertReq req) {
        CommonResp<Object> resp = new CommonResp<>();
        categoryService.insert(req);
        return resp;
    }
    @ApiOperation(value = "删除文章分类")
    @DeleteMapping("/delete/{id}")
    public CommonResp deleteTag(@PathVariable("id") Integer id) {
        return categoryService.delete(id);
    }
}
