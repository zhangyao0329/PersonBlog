package com.dkt.blogboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BlogBootApplicationTests {

    @Test
    void contextLoads() {
//        AntPathMatcher antPathMatcher = new AntPathMatcher();
//        System.out.println(antPathMatcher.match("/**/a/b", "/1/2/3/a"));
    }

}
