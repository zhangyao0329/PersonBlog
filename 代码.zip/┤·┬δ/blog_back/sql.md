```sql
create database blog;
use blog;



-- auto-generated definition
create table article
(
    id      int auto_increment
        primary key,
    title   varchar(255) null,
    content text         null,
    date    datetime     null,
    view    int          null,
    praise  int          null
)
    collate = utf8mb3_bin
    row_format = DYNAMIC;



-- auto-generated definition
create table user
(
    id       int auto_increment
        primary key,
    username varchar(255) null,
    password varchar(255) null,
    nickname varchar(255) null
)
    collate = utf8mb3_bin
    row_format = DYNAMIC;

-- auto-generated definition
create table tag
(
    id  int auto_increment
        primary key,
    tag varchar(255) null
)
    collate = utf8mb3_bin
    row_format = DYNAMIC;

-- auto-generated definition
create table category
(
    id       int auto_increment
        primary key,
    category varchar(255) null
)
    collate = utf8mb3_bin
    row_format = DYNAMIC;


-- auto-generated definition
create table article_tag
(
    id  int auto_increment
        primary key,
    aid int null,
    tid int null,
    constraint article_tag_ibfk_1
        foreign key (aid) references article (id),
    constraint article_tag_ibfk_2
        foreign key (tid) references tag (id)
)
    collate = utf8mb3_bin
    row_format = DYNAMIC;

create index aid
    on article_tag (aid);

create index tid
    on article_tag (tid);

-- auto-generated definition
create table article_category
(
    id  int auto_increment
        primary key,
    aid int null,
    cid int null,
    constraint article_category_ibfk_1
        foreign key (aid) references article (id),
    constraint article_category_ibfk_2
        foreign key (cid) references category (id)
)
    collate = utf8mb3_bin
    row_format = DYNAMIC;

create index aid
    on article_category (aid);

create index cid
    on article_category (cid);
```